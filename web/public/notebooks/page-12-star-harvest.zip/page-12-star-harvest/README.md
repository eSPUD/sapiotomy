# Page 12, "Which chains become lessons?": the run behind section 2

Everything page 12's section 2 draws, plus the code that drew it and every chain it rests on.

```
page-12-star-harvest/
  page_12_star_harvest.ipynb     the notebook: STaR's filter over page 7's pile, and the hint retry
  page_12_site_data.py           builds derived.json from results.json
  harness.py                     shared plumbing (model loading, generation, resume log)
  requirements.txt
  out/page_07/
    traces.jsonl                 page 7's chains: 16 per problem, plus one greedy chain
  out/page_12/
    results.json                 every number the notebook computes, and the page's claims
    manifest.json                model, item set, decoding, versions, hashes
    hint_traces.jsonl            the hinted chains, one per problem the greedy chain missed
    derived.json                 what the page draws, built by page_12_site_data.py
```

## Re-derive the figure without a GPU

The notebook opens in `RUN_MODE = "REPLAY"`, which loads no model. It reads page 7's chains, runs
the filter under both rules for every number of attempts, and reads the hint retry from
`hint_traces.jsonl`.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
jupyter lab page_12_star_harvest.ipynb
```

Run it from this directory. Then rebuild what the page draws:

```bash
python page_12_site_data.py
```

## What the run is

Nothing is trained. Page 7 asked Qwen2.5-3B-Instruct (bf16) each of 100 MATH-500 problems at
levels 4 and 5 sixteen times, at temperature 0.3 with a 2,048-token cap. This notebook keeps a
chain when its answer matches the answer key (STaR) or matches the answer most of the problem's
chains gave (the key taken away), and counts what each rule keeps at 1 to 16 attempts.

The hint retry is STaR's rationalization step: each problem whose greedy chain was wrong is asked
again, greedily, with the right answer written into the question. Re-running it needs a GPU with
about 8 GB (`PAGE12_RUN_MODE=HINT`).

Grading is `extract_final_candidate` then `grade_answer` from chapter 3 of Sebastian Raschka's
[reasoning-from-scratch](https://github.com/rasbt/reasoning-from-scratch), used unchanged.
