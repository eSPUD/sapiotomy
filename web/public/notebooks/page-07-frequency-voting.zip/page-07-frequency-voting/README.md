# Page 7, "Frequency Voting" — the run behind the figures

Everything page 7 draws, plus the code that drew it and every chain it rests on.

```
page-07-frequency-voting/
  page_07_frequency_voting.ipynb   the notebook: the pile, the gates, every figure
  harness.py                       shared plumbing (model loading, token strings, resume log)
  requirements.txt
  out/page_07/
    traces.jsonl                   all 5,920 records, one JSON object per line
    derived.json                   the aggregates the page plots
    manifest.json                  models, decoding, item set, versions, hashes
```

## Re-draw the figures without a GPU

This copy of the notebook opens in `RUN_MODE = "REPLAY"`, which loads no model. It adopts the
published `RUN_ID`, asserts the chains cover the item set it draws from the seed and band, then
runs every gate, assertion and figure the generating run did.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
jupyter lab page_07_frequency_voting.ipynb
```

Run it from this directory, with `harness.py` beside the notebook and `out/page_07/traces.jsonl`
where you found it. What REPLAY cannot tell you is whether your hardware reproduces ours.

The copy in the repository is left at `RUN_MODE = "FULL"`, which is the configuration that
produced this run: `manifest.json` records that file's sha256, so the claim "this notebook made
these numbers" is checkable rather than asserted. Flipping one string is the only difference
between the two copies.

## What the run is

Qwen2.5-3B-Instruct at bf16, MATH-500 levels 4 and 5, the same 100 items pages 5 and 6 use, 16
chains per problem sampled at temperature 0.3 with top-p 0.95 and a 2,048-token cap, plus a
temperature sweep on a 30-item subset. A chain that reaches the cap is made to commit rather than
left unanswered.

Two chains count as agreeing when the grader says their answers are equivalent, so `1/2` and `0.5`
are one bucket rather than two. A tie returns no answer and grades wrong. Grading is
`extract_final_candidate` then `grade_answer` from chapter 3 of Sebastian Raschka's
[reasoning-from-scratch](https://github.com/rasbt/reasoning-from-scratch), used unchanged, so
grading is not ours to defend. Every number on the page is ours.

The N axis is one pile of 16 chains subsampled 64 times per problem at each N, so chain length is
fixed and the only thing changing is how many candidates the vote sees. Intervals and the paired
test are over the 100 items, which are the independent unit.

Sampling is seeded per group of chains, and floating-point reduction order shifts with batch size
and hardware. Re-deriving reproduces the shape and the ranking, not every digit.

This is pages 5 and 6's instrument on the same item draw, so the three pages are one measurement
read three ways.
