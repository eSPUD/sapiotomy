# Page 8 — Best-of-N and Verifiers

Everything page 8 draws, and the generations it drew them from.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
jupyter lab page_08_best_of_n.ipynb
```

`RUN_MODE` is set to `REPLAY`. Run all: it loads no model, touches no GPU, and reproduces
every figure and every number on the page in about two minutes from the files in `out/`.

## What is in here

| file | what |
|---|---|
| `page_08_best_of_n.ipynb` | the notebook that produced everything below |
| `harness.py` | shared plumbing: model loading, resume log, provenance hashes, the exact McNemar |
| `out/page_08/traces.jsonl` | **12,800 generations.** 100 MATH-500 level 4-5 problems, `Qwen2.5-3B-Instruct`, four temperatures, 16 to 64 chains each |
| `out/page_08/scores.jsonl` | **70,960 judgements.** One row per (candidate, judge) |
| `out/page_08/judge_solves.jsonl` | what `Qwen2.5-Math-1.5B-Instruct` solves on its own, one greedy chain per problem |
| `out/page_08/derived.json` | the aggregates the page plots, plus the claims block it is gated on |
| `out/page_08/manifest.json` | model revisions, hashes, seeds, versions, dates |

## Two things about these files

**`scores.jsonl` holds rows from two runs.** The shipped pool, and an earlier pilot that scored
page 7's candidates instead. They are keyed by `run_id` and the notebook replays only the one it
names, so the extra rows change nothing. They are here because they are the record of what was
actually run, and deleting them would edit that record.

**The trained verifier is a process reward model used as an outcome one.** It is read at the
final token, one number for the whole solution, never per step. It appears here as a *trained
verifier*, which is the property being tested. Step-level scoring is page 9's subject.

## Re-running it for real

`RUN_MODE = "SCORE"` re-scores the pool on your own hardware, about an hour on a 16 GB card and
no generation. `RUN_MODE = "GENERATE"` makes a fresh pool, about six hours. Both resume: delete
the relevant file in `out/page_08/` to start over.

Temperature sampling is not reproducible across machines, so **the transcripts are the
provenance**. The analysis is deterministic from them, and the notebook's section 13 recomputes
page 7's headline from page 7's own file as a cross-check.

The grading harness is Sebastian Raschka's
[reasoning-from-scratch](https://github.com/rasbt/reasoning-from-scratch): `load_math500_test`,
`render_prompt`, `extract_final_candidate` and `grade_answer` from ch03, and the two scorers from
ch05. Grading is not ours to defend. The sweep, the judges and every number are ours.
