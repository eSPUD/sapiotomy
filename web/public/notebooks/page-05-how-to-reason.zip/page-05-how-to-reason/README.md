# Page 5, "How to Reason" — the run behind the figures

Everything page 5 draws, plus the code that drew it and every generation it rests on.

```
page-05-how-to-reason/
  page_05_how_to_reason.ipynb   the notebook: the sweep, the gates, every figure
  harness.py                    shared plumbing (model loading, token strings, resume log)
  requirements.txt
  out/page_05/
    traces.jsonl                all 900 generations, one JSON object per line
    derived.json                the aggregates the page plots
    manifest.json               models, decoding, item set, versions, hashes
```

## Re-draw the figures without a GPU

The notebook opens in `RUN_MODE = "REPLAY"`, which loads no model. It adopts the published
`RUN_ID`, asserts the traces cover the item set it draws from the seed and band, then runs every
gate, assertion and figure the generating run did, including the independent verification that
recomputes the headline numbers straight from `traces.jsonl`. About a minute.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
jupyter lab page_05_how_to_reason.ipynb
```

Run it from this directory, with `harness.py` beside the notebook and `out/page_05/traces.jsonl`
where you found it. What REPLAY cannot tell you is whether your hardware reproduces ours.

## Re-run it on your own hardware

Set `RUN_MODE = "QUICK"` for one 3B on 50 items (about 150 generations, a ~6 GB card, tens of
minutes), or `"FULL"` for the shipped grid: three models, 100 items, 900 generations, several
hours. Delete `out/page_05/traces.jsonl` first, or it resumes.

Greedy decoding diverges on a handful of items across hardware. Re-deriving reproduces the shape
and the ranking, not every digit.

## What the run is

Qwen2.5-Instruct at bf16 (1.5B, 3B, 7B; the 3B is the primary), MATH-500 levels 4 and 5, 100
paired items, greedy, a 2048-token cap. Three prompt conditions, identical apart from a suffix:
`forced_blurt`, `bare` and `zero_shot_cot`. Grading is `extract_final_candidate` then
`grade_answer` from chapter 3 of Sebastian Raschka's
[reasoning-from-scratch](https://github.com/rasbt/reasoning-from-scratch), used unchanged, so
grading is not ours to defend. Every number on the page is ours.

Contrasts are paired and use exact McNemar over discordant items; the discordant counts sit
beside every contrast on the page.
