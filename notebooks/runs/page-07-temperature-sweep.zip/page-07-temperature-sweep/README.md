# Page 7: temperature sweep

16 chains at 12 temperatures (0, 0.1, ..., 1.1) on 40 of page 7's 100 MATH-500 problems
(levels 4 and 5), Qwen2.5-3B-Instruct, 2048-token cap, top-p 0.95. Then one fresh chain on
all 100 problems at the temperature whose vote solved the most of the 40.

- `results.json`: `heatmap` (one entry per problem, one cell per temperature, with the
  vote's outcome: right, wrong or tie), `summary` (one row per temperature), the
  `best_temperature`, and the `control` against one greedy chain.
- `timing.json`: wall clock for the whole run and for every stage.
- `traces.jsonl`: all 7,780 chains these are built from, one JSON record per line.
- `page_07_temperature_sweep.py`, `page_07_topup.py`: the code that made them. They run
  inside the repository's `notebooks/` folder, next to page 7's notebook.
